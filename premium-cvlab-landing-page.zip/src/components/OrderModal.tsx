import { useEffect, useRef, useState, type DragEvent, type FormEvent } from "react";
import { Button } from "./Button";
import { ArrowRight, Check, FileText, GradCap, Lock, Shield, Upload, X } from "./Icons";
import { PLANS, type PlanId } from "./OrderContext";
import { cn } from "../utils/cn";

type Props = { isOpen: boolean; plan: PlanId; onClose: () => void };

export function OrderModal({ isOpen, plan: initialPlan, onClose }: Props) {
  const [plan, setPlan] = useState<PlanId>(initialPlan);
  const [student, setStudent] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [drag, setDrag] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", role: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");
  const dialogRef = useRef<HTMLDivElement>(null);
  const firstInput = useRef<HTMLInputElement>(null);
  const lastFocus = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setPlan(initialPlan);
      setStatus("idle");
      setErrors({});
      lastFocus.current = document.activeElement as HTMLElement;
      document.body.style.overflow = "hidden";
      setTimeout(() => firstInput.current?.focus(), 80);
    } else {
      document.body.style.overflow = "";
      lastFocus.current?.focus?.();
    }
  }, [isOpen, initialPlan]);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab" && dialogRef.current) {
        const f = dialogRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), input:not([disabled]), [href], [tabindex]:not([tabindex="-1"])',
        );
        if (!f.length) return;
        const first = f[0];
        const last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isOpen, onClose]);

  const selected = PLANS.find((p) => p.id === plan)!;
  const price = student ? Math.round(selected.price * 0.8) : selected.price;

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDrag(false);
    const f = e.dataTransfer.files?.[0];
    if (f) setFile(f);
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = "Please enter your name";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) errs.email = "Please enter a valid email";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setStatus("loading");
    setTimeout(() => setStatus("done"), 1300);
  };

  return (
    <div
      className={cn(
        "fixed inset-0 z-[100] flex items-end justify-center sm:items-center sm:p-6",
        isOpen ? "pointer-events-auto" : "pointer-events-none",
      )}
      aria-hidden={!isOpen}
    >
      <div
        onClick={onClose}
        className={cn(
          "absolute inset-0 bg-ink-950/50 backdrop-blur-sm transition-opacity duration-500",
          isOpen ? "opacity-100" : "opacity-0",
        )}
      />
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="order-title"
        className={cn(
          "relative max-h-[94vh] w-full max-w-xl overflow-y-auto rounded-t-[32px] bg-white shadow-2xl transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] sm:rounded-[32px]",
          isOpen ? "translate-y-0 scale-100 opacity-100" : "translate-y-10 scale-[0.97] opacity-0",
        )}
      >
        {isOpen && (
          <>
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white/85 px-6 py-4 backdrop-blur sm:px-8">
              <div>
                <h2 id="order-title" className="text-lg font-semibold tracking-tight">
                  {status === "done" ? "Order confirmed" : "Start your order"}
                </h2>
                {status !== "done" && <p className="text-xs text-slate-500">Takes about 2 minutes · No payment until you approve your brief</p>}
              </div>
              <button onClick={onClose} aria-label="Close" className="grid h-9 w-9 place-items-center rounded-full bg-slate-100 text-slate-600 transition hover:rotate-90 hover:bg-slate-200">
                <X className="h-4 w-4" />
              </button>
            </div>

            {status === "done" ? (
              <div className="px-6 py-12 text-center sm:px-10">
                <div className="relative mx-auto grid h-20 w-20 place-items-center">
                  <span className="animate-pulse-ring absolute inset-0 rounded-full bg-emerald-300" />
                  <span className="relative grid h-20 w-20 place-items-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 text-white shadow-xl shadow-emerald-500/30">
                    <Check className="h-9 w-9" strokeWidth={2.5} />
                  </span>
                </div>
                <h3 className="mt-6 text-2xl font-semibold tracking-tight">You're all set, {form.name.split(" ")[0]}! 🎉</h3>
                <p className="mx-auto mt-3 max-w-sm text-slate-600">
                  We've emailed <b className="text-ink-900">{form.email}</b> with next steps. Your {selected.name} writer will be in touch within 2 hours.
                </p>
                <div className="mx-auto mt-6 max-w-sm rounded-2xl bg-slate-50 p-4 text-left text-sm ring-1 ring-slate-100">
                  <div className="flex justify-between"><span className="text-slate-500">Package</span><span className="font-medium">{selected.name}</span></div>
                  <div className="mt-2 flex justify-between"><span className="text-slate-500">Delivery</span><span className="font-medium">{selected.delivery}</span></div>
                  <div className="mt-2 flex justify-between"><span className="text-slate-500">Total</span><span className="font-medium">£{price}</span></div>
                </div>
                <Button className="mt-8" size="lg" onClick={onClose}>Back to site</Button>
              </div>
            ) : (
              <form onSubmit={submit} noValidate className="space-y-6 px-6 py-6 sm:px-8">
                <fieldset>
                  <legend className="text-sm font-medium text-ink-900">Choose your package</legend>
                  <div className="mt-3 grid gap-2.5">
                    {PLANS.map((p) => {
                      const pr = student ? Math.round(p.price * 0.8) : p.price;
                      const active = plan === p.id;
                      return (
                        <label
                          key={p.id}
                          className={cn(
                            "relative flex cursor-pointer items-center gap-4 rounded-2xl border p-4 transition-all duration-300",
                            active ? "border-indigo-500 bg-indigo-50/50 shadow-[0_0_0_3px_rgba(99,102,241,0.15)]" : "border-slate-200 hover:border-slate-300",
                          )}
                        >
                          <input type="radio" name="plan" value={p.id} checked={active} onChange={() => setPlan(p.id)} className="sr-only" />
                          <span className={cn("grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 transition", active ? "border-indigo-600" : "border-slate-300")}>
                            <span className={cn("h-2.5 w-2.5 rounded-full bg-indigo-600 transition-transform", active ? "scale-100" : "scale-0")} />
                          </span>
                          <span className="flex-1">
                            <span className="flex items-center gap-2 text-sm font-semibold">
                              {p.name}
                              {p.popular && <span className="rounded-full bg-indigo-600 px-2 py-0.5 text-[10px] font-semibold text-white">Popular</span>}
                            </span>
                            <span className="block text-xs text-slate-500">{p.delivery}</span>
                          </span>
                          <span className="text-right">
                            <span className="block font-semibold tabular-nums">£{pr}</span>
                            {student && <span className="block text-xs text-slate-400 line-through">£{p.price}</span>}
                          </span>
                        </label>
                      );
                    })}
                  </div>
                  <label className="mt-3 flex cursor-pointer items-center gap-3 rounded-2xl bg-emerald-50/60 p-3 text-sm ring-1 ring-emerald-100">
                    <input type="checkbox" checked={student} onChange={(e) => setStudent(e.target.checked)} className="h-4 w-4 accent-emerald-600" />
                    <GradCap className="h-4 w-4 text-emerald-600" />
                    <span className="text-slate-700">I'm a student — apply <b>20% off</b></span>
                  </label>
                </fieldset>

                <div className="grid gap-4 sm:grid-cols-2">
                  {[
                    { k: "name" as const, label: "Full name", type: "text", ac: "name", ph: "Alex Morgan", ref: firstInput },
                    { k: "email" as const, label: "Email", type: "email", ac: "email", ph: "alex@email.com" },
                  ].map((f) => (
                    <div key={f.k}>
                      <label htmlFor={`o-${f.k}`} className="text-sm font-medium text-ink-900">{f.label}</label>
                      <input
                        ref={f.ref}
                        id={`o-${f.k}`}
                        type={f.type}
                        autoComplete={f.ac}
                        placeholder={f.ph}
                        value={form[f.k]}
                        onChange={(e) => setForm({ ...form, [f.k]: e.target.value })}
                        aria-invalid={!!errors[f.k]}
                        aria-describedby={errors[f.k] ? `o-${f.k}-err` : undefined}
                        className={cn(
                          "mt-1.5 h-12 w-full rounded-xl border bg-white px-4 text-[15px] transition placeholder:text-slate-400 focus:border-indigo-500 focus:shadow-[0_0_0_4px_rgba(99,102,241,0.12)] focus:outline-none",
                          errors[f.k] ? "border-rose-400" : "border-slate-200",
                        )}
                      />
                      {errors[f.k] && <p id={`o-${f.k}-err`} className="mt-1 text-xs text-rose-500">{errors[f.k]}</p>}
                    </div>
                  ))}
                </div>

                <div>
                  <label htmlFor="o-role" className="text-sm font-medium text-ink-900">Target role <span className="font-normal text-slate-400">(optional)</span></label>
                  <input
                    id="o-role"
                    type="text"
                    placeholder="e.g. Graduate Software Engineer"
                    value={form.role}
                    onChange={(e) => setForm({ ...form, role: e.target.value })}
                    className="mt-1.5 h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-[15px] transition placeholder:text-slate-400 focus:border-indigo-500 focus:shadow-[0_0_0_4px_rgba(99,102,241,0.12)] focus:outline-none"
                  />
                </div>

                <div>
                  <p className="text-sm font-medium text-ink-900">Current CV <span className="font-normal text-slate-400">(optional)</span></p>
                  <label
                    onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
                    onDragLeave={() => setDrag(false)}
                    onDrop={onDrop}
                    className={cn(
                      "mt-1.5 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-4 py-6 text-center transition-all duration-300 focus-within:border-indigo-500",
                      drag ? "scale-[1.01] border-indigo-500 bg-indigo-50" : file ? "border-emerald-300 bg-emerald-50/50" : "border-slate-200 hover:border-slate-300 hover:bg-slate-50",
                    )}
                  >
                    <input type="file" accept=".pdf,.doc,.docx" className="sr-only" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
                    {file ? (
                      <span className="flex items-center gap-2 text-sm font-medium text-emerald-700">
                        <FileText className="h-5 w-5" /> {file.name}
                      </span>
                    ) : (
                      <>
                        <span className={cn("grid h-10 w-10 place-items-center rounded-xl bg-white text-indigo-600 shadow-sm ring-1 ring-slate-200 transition-transform", drag && "-translate-y-1")}>
                          <Upload className="h-5 w-5" />
                        </span>
                        <span className="mt-2 text-sm text-slate-700"><b className="text-indigo-600">Click to upload</b> or drag & drop</span>
                        <span className="text-xs text-slate-400">PDF or Word, up to 10MB</span>
                      </>
                    )}
                  </label>
                </div>

                <div className="sticky bottom-0 -mx-6 border-t border-slate-100 bg-white/90 px-6 pt-4 pb-6 backdrop-blur sm:-mx-8 sm:px-8">
                  <Button type="submit" size="lg" className="w-full" disabled={status === "loading"}>
                    {status === "loading" ? (
                      <>
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" /> Securing your writer…
                      </>
                    ) : (
                      <>
                        Continue — £{price} <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </>
                    )}
                  </Button>
                  <div className="mt-3 flex items-center justify-center gap-4 text-xs text-slate-500">
                    <span className="inline-flex items-center gap-1"><Lock className="h-3.5 w-3.5" /> Secure & encrypted</span>
                    <span className="inline-flex items-center gap-1"><Shield className="h-3.5 w-3.5" /> Interview Guarantee</span>
                  </div>
                </div>
              </form>
            )}
          </>
        )}
      </div>
    </div>
  );
}
