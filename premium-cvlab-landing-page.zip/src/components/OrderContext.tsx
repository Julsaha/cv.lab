import { createContext, useContext } from "react";

export type PlanId = "starter" | "pro" | "career";

export type OrderCtx = {
  open: (plan?: PlanId) => void;
};

export const OrderContext = createContext<OrderCtx>({ open: () => {} });
export const useOrder = () => useContext(OrderContext);

export const PLANS: {
  id: PlanId;
  name: string;
  price: number;
  tagline: string;
  delivery: string;
  features: string[];
  popular?: boolean;
}[] = [
  {
    id: "starter",
    name: "CV Refresh",
    price: 49,
    tagline: "For students & first jobs",
    delivery: "3-day delivery",
    features: [
      "Professional CV rewrite (1–2 pages)",
      "ATS keyword optimisation",
      "Modern, recruiter-tested template",
      "1 round of revisions",
      "PDF + editable Word files",
    ],
  },
  {
    id: "pro",
    name: "Job-Ready Pro",
    price: 99,
    tagline: "Our most-loved package",
    delivery: "48-hour delivery",
    popular: true,
    features: [
      "Everything in CV Refresh",
      "Tailored cover letter template",
      "LinkedIn profile makeover",
      "1:1 kick-off call with your writer",
      "Unlimited revisions for 30 days",
      "Interview Guarantee",
    ],
  },
  {
    id: "career",
    name: "Career Accelerator",
    price: 189,
    tagline: "For career changers & senior roles",
    delivery: "Priority 24-hour delivery",
    features: [
      "Everything in Job-Ready Pro",
      "2 × 45-min mock interviews",
      "3 role-tailored CV versions",
      "Salary negotiation playbook",
      "60 days of job-search support",
    ],
  },
];
