import { useState, type FormEvent } from "react";
import { Button } from "../components/Button";
import { ArrowRight, Check, Sparkles } from "../components/Icons";
import { useOrder } from "../components/OrderContext";
import { Reveal } from "../components/Reveal";
import { AVATARS } from "./Hero";

export function CTA() {
  const { open } = useOrder();
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setState("error");
      return;
    }
    setState("loading");
    setTimeout(() => setState("done"), 1100);
  };

  return (
    <section aria-labelledby="cta-title" className="relative px-3 py-10 sm:px-4 sm:py-16">
      <Reveal>
        <div className="noise relative mx-auto max-w-6xl overflow-hidden rounded-[36px] bg-gradient-to-br from-indigo-600 via-violet-600 to-indigo-800 px-6 py-16 text-center text-white sm:rounded-[44px] sm:px-12 sm:py-24">
          <div aria-hidden className="pointer-events-none absolute inset-0">
            <div className="animate-blob absolute -top-24 -left-24 h-96 w-96 rounded-full bg-cyan-400/40 blur-[100px]" />
            <div className="animate-blob absolute -right-24 -bottom-32 h-[420px] w-[420px] rounded-full bg-fuchsia-500/40 blur-[100px] [animation-delay:-9s]" />
            <div className="absolute inset-0 [background-image:linear-gradient(rgba(255,255,255,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.06)_1px,transparent_1px)] [background-size:48px_48px] [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]" />
            <div className="animate-spin-slow absolute top-1/2 left-1/2 h-[700px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-white/10" />
          </div>

          <div className="relative mx-auto max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-medium ring-1 ring-white/20 backdrop-blur">
              <span className="relative flex h-2 w-2">
                <span className="animate-pulse-ring absolute inline-flex h-full w-full rounded-full bg-emerald-300" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-300" />
              </span>
              Only 14 priority slots left this week
            </span>
            <h2 id="cta-title" className="mt-6 text-4xl font-semibold tracking-[-0.04em] text-balance sm:text-5xl md:text-6xl">
              Stop applying into the void.{" "}
              <span className="font-serif font-normal italic">Start getting callbacks.</span>
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-lg text-indigo-100/90">
              Get a free, no-obligation CV review from a real expert within 24 hours — and see exactly what's holding you back.
            </p>

            {state === "done" ? (
              <div role="status" className="mx-auto mt-10 flex max-w-md items-center gap-3 rounded-2xl bg-white/15 p-4 text-left ring-1 ring-white/25 backdrop-blur [animation:pop_0.5s_cubic-bezier(.34,1.56,.64,1)]">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-emerald-400 text-ink-900">
                  <Check />
                </span>
                <p className="text-sm">
                  <b>You're in!</b> Check <span className="underline decoration-white/40">{email}</span> — we've sent a secure link to upload your CV.
                </p>
              </div>
            ) : (
              <form onSubmit={submit} className="mx-auto mt-10 max-w-md" noValidate>
                <div className="flex flex-col gap-2 rounded-3xl bg-white/10 p-2 ring-1 ring-white/20 backdrop-blur-xl transition focus-within:bg-white/15 focus-within:ring-white/40 sm:flex-row sm:rounded-full">
                  <label htmlFor="cta-email" className="sr-only">Email address</label>
                  <input
                    id="cta-email"
                    type="email"
                    required
                    autoComplete="email"
                    placeholder="you@email.com"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (state === "error") setState("idle");
                    }}
                    aria-invalid={state === "error"}
                    aria-describedby={state === "error" ? "cta-err" : undefined}
                    className="h-12 min-w-0 flex-1 rounded-full bg-transparent px-5 text-white placeholder:text-indigo-200/70 focus:outline-none"
                  />
                  <Button type="submit" variant="light" size="lg" disabled={state === "loading"} className="h-12">
                    {state === "loading" ? (
                      <>
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-ink-900/20 border-t-ink-900" /> Sending…
                      </>
                    ) : (
                      <>
                        Get free review <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </>
                    )}
                  </Button>
                </div>
                {state === "error" && (
                  <p id="cta-err" role="alert" className="mt-3 text-sm text-rose-200">Please enter a valid email address.</p>
                )}
              </form>
            )}

            <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <div className="flex -space-x-2">
                {AVATARS.slice(3, 7).map((a) => (
                  <img key={a} src={a} alt="" loading="lazy" className="h-8 w-8 rounded-full object-cover ring-2 ring-indigo-600" />
                ))}
              </div>
              <p className="text-sm text-indigo-100/80">
                Or skip the queue —{" "}
                <button onClick={() => open("pro")} className="inline-flex items-center gap-1 font-medium text-white underline decoration-white/40 underline-offset-4 transition hover:decoration-white">
                  order your rewrite now <Sparkles className="h-3.5 w-3.5" />
                </button>
              </p>
            </div>
          </div>
        </div>
      </Reveal>
      <style>{`@keyframes pop { from { transform: scale(.9); opacity: 0; } to { transform: none; opacity: 1; } }`}</style>
    </section>
  );
}
