import { useState } from "react";
import { Button } from "../components/Button";
import { ArrowRight, Check, GradCap, Shield, Lock, Zap } from "../components/Icons";
import { PLANS, useOrder } from "../components/OrderContext";
import { Reveal, SectionHeading } from "../components/Reveal";
import { cn } from "../utils/cn";

export function Pricing() {
  const { open } = useOrder();
  const [student, setStudent] = useState(false);

  return (
    <section id="pricing" className="relative overflow-hidden py-20 sm:py-28">
      <div aria-hidden className="absolute top-40 left-1/2 -z-10 h-[600px] w-[900px] -translate-x-1/2 rounded-full bg-gradient-to-r from-indigo-200/40 via-violet-200/30 to-cyan-200/40 blur-3xl" />
      <div className="mx-auto max-w-6xl px-5 sm:px-6">
        <SectionHeading
          eyebrow="Pricing"
          title={
            <>
              One investment. <span className="font-serif font-normal italic text-gradient">A career of returns.</span>
            </>
          }
          subtitle="Transparent, one-off pricing. No subscriptions, no surprises — and every package is backed by our guarantee."
        />

        <Reveal delay={200}>
          <div className="mt-10 flex items-center justify-center gap-3">
            <span className={cn("text-sm transition-colors", !student ? "font-medium text-ink-900" : "text-slate-500")}>
              Standard
            </span>
            <button
              role="switch"
              aria-checked={student}
              aria-label="Apply student pricing"
              onClick={() => setStudent((s) => !s)}
              className={cn(
                "relative h-8 w-14 rounded-full p-1 transition-colors duration-300",
                student ? "bg-gradient-to-r from-indigo-500 to-violet-500" : "bg-slate-200",
              )}
            >
              <span
                className={cn(
                  "block h-6 w-6 rounded-full bg-white shadow-md transition-transform duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)]",
                  student && "translate-x-6",
                )}
              />
            </button>
            <span className={cn("inline-flex items-center gap-1.5 text-sm transition-colors", student ? "font-medium text-ink-900" : "text-slate-500")}>
              <GradCap className="h-4 w-4" /> Student
              <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">−20%</span>
            </span>
          </div>
        </Reveal>

        <div className="mt-12 grid items-stretch gap-5 lg:grid-cols-3">
          {PLANS.map((p, i) => {
            const price = student ? Math.round(p.price * 0.8) : p.price;
            return (
              <Reveal key={p.id} delay={i * 110} className={cn(p.popular && "lg:-my-4")}>
                <article
                  className={cn(
                    "group relative flex h-full flex-col rounded-[28px] p-7 transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] sm:p-8",
                    p.popular
                      ? "ring-gradient bg-ink-900 text-white shadow-[0_40px_80px_-30px_rgba(79,70,229,0.6)] hover:-translate-y-1.5"
                      : "border border-slate-200/80 bg-white/80 backdrop-blur hover:-translate-y-1 hover:border-slate-300 hover:shadow-[0_30px_60px_-35px_rgba(30,27,75,0.35)]",
                  )}
                >
                  {p.popular && (
                    <>
                      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden rounded-[28px]">
                        <div className="absolute -top-20 -right-20 h-60 w-60 rounded-full bg-indigo-500/40 blur-3xl" />
                        <div className="absolute -bottom-20 -left-10 h-48 w-48 rounded-full bg-cyan-400/20 blur-3xl" />
                      </div>
                      <span className="absolute -top-3.5 left-1/2 z-10 inline-flex -translate-x-1/2 items-center gap-1 rounded-full bg-gradient-to-r from-indigo-500 via-violet-500 to-cyan-400 px-3.5 py-1 text-xs font-semibold whitespace-nowrap text-white shadow-lg shadow-indigo-500/40">
                        <Zap className="h-3 w-3" /> Most popular · 68% choose this
                      </span>
                    </>
                  )}
                  <div className="relative">
                    <h3 className={cn("text-lg font-semibold tracking-tight", p.popular ? "text-white" : "text-ink-900")}>{p.name}</h3>
                    <p className={cn("mt-1 text-sm", p.popular ? "text-slate-400" : "text-slate-500")}>{p.tagline}</p>

                    <div className="mt-6 flex items-end gap-2">
                      <span className="relative overflow-hidden text-5xl font-semibold tracking-[-0.04em] tabular-nums">
                        <span key={price} className="inline-block [animation:price-in_0.5s_cubic-bezier(.16,1,.3,1)]">
                          £{price}
                        </span>
                      </span>
                      <div className="pb-1.5">
                        {student && (
                          <p className={cn("text-sm line-through", p.popular ? "text-slate-500" : "text-slate-400")}>£{p.price}</p>
                        )}
                        <p className={cn("text-sm", p.popular ? "text-slate-400" : "text-slate-500")}>one-off</p>
                      </div>
                    </div>
                    <p className={cn("mt-2 inline-flex items-center gap-1.5 text-xs font-medium", p.popular ? "text-cyan-300" : "text-indigo-600")}>
                      <span className="h-1.5 w-1.5 rounded-full bg-current" />
                      {p.delivery}
                    </p>

                    <Button
                      variant={p.popular ? "light" : "primary"}
                      size="lg"
                      className="mt-7 w-full"
                      onClick={() => open(p.id)}
                      aria-label={`Choose ${p.name} for £${price}`}
                    >
                      Choose {p.name}
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Button>

                    <ul className="mt-8 space-y-3.5">
                      {p.features.map((f) => (
                        <li key={f} className="flex items-start gap-3 text-[15px]">
                          <span
                            className={cn(
                              "mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full",
                              p.popular ? "bg-gradient-to-br from-indigo-400 to-cyan-400 text-white" : "bg-indigo-50 text-indigo-600",
                            )}
                          >
                            <Check className="h-3 w-3" strokeWidth={2.5} />
                          </span>
                          <span className={p.popular ? "text-slate-200" : "text-slate-700"}>{f}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={200}>
          <div className="mt-14 flex flex-col items-center justify-center gap-4 text-sm text-slate-500 sm:flex-row sm:gap-8">
            <span className="inline-flex items-center gap-2"><Shield className="h-4 w-4 text-emerald-500" /> 60-day Interview Guarantee</span>
            <span className="inline-flex items-center gap-2"><Lock className="h-4 w-4 text-emerald-500" /> Secure checkout · Klarna available</span>
            <span className="inline-flex items-center gap-2"><Check className="h-4 w-4 text-emerald-500" /> Free ATS scan included</span>
          </div>
        </Reveal>
      </div>
      <style>{`@keyframes price-in { from { transform: translateY(60%); opacity: 0; filter: blur(4px);} to { transform: none; opacity: 1; filter: none; } }`}</style>
    </section>
  );
}
